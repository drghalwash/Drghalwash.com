const TAGS = [
    'Node.js', 'Express', 'Bootstrap', 'JavaScript', 'HTML',
    'CSS', 'MongoDB', 'REST API', 'Docker', 'AWS',
    'Git', 'CI/CD', 'Testing', 'Performance', 'Accessibility'
];

const TAGS_PER_ROW = 5;
const BASE_DURATION = 15000;

function shuffle(array) {
    return [...array].sort(() => Math.random() - 0.5);
}

function random(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

function createTag(text) {
    const tag = document.createElement('span');
    tag.className = 'tag';
    tag.innerHTML = `<i class="hash">#</i>${text}`;
    
    // Touch and mouse events
    const handleInteraction = (e) => {
        e.preventDefault();
        tag.classList.add('active');
    };
    
    const handleInteractionEnd = (e) => {
        e.preventDefault();
        tag.classList.remove('active');
    };
    
    tag.addEventListener('mouseenter', handleInteraction);
    tag.addEventListener('mouseleave', handleInteractionEnd);
    tag.addEventListener('touchstart', handleInteraction);
    tag.addEventListener('touchend', handleInteractionEnd);
    
    return tag;
}

function initializeRows() {
    const rows = document.querySelectorAll('.tag-row');
    
    rows.forEach((row, index) => {
        // Create three sets of tags for smooth looping
        const tags = shuffle(TAGS).slice(0, TAGS_PER_ROW);
        const duration = random(BASE_DURATION - 5000, BASE_DURATION + 5000);
        
        row.style.animationDuration = `${duration}ms`;
        
        // Add three sets of tags
        for (let i = 0; i < 3; i++) {
            tags.forEach(tag => {
                row.appendChild(createTag(tag));
            });
        }
    });
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', initializeRows);