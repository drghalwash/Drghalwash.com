import React, { useState } from 'react';
import { Hash } from 'lucide-react';

const TAGS = [
  'React', 'TypeScript', 'JavaScript', 'Tailwind CSS', 'Next.js',
  'Node.js', 'GraphQL', 'REST API', 'Docker', 'AWS',
  'Git', 'CI/CD', 'Testing', 'Performance', 'Accessibility'
];

const DURATION = 15000;
const ROWS = 5;
const TAGS_PER_ROW = 5;

const random = (min: number, max: number) => Math.floor(Math.random() * (max - min)) + min;
const shuffle = (arr: string[]) => [...arr].sort(() => 0.5 - Math.random());

interface SliderProps {
  children: React.ReactNode;
  duration: number;
  reverse?: boolean;
}

const InfiniteLoopSlider: React.FC<SliderProps> = ({ children, duration, reverse = false }) => (
  <div className="loop-slider overflow-hidden relative">
    <div 
      className="inner whitespace-nowrap"
      style={{
        '--duration': `${duration}ms`,
        '--direction': reverse ? 'reverse' : 'normal'
      } as React.CSSProperties}
    >
      {children}
      {children}
      {children} {/* Add an extra set for smoother looping */}
    </div>
  </div>
);

interface TagProps {
  text: string;
}

const Tag: React.FC<TagProps> = ({ text }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      className={`tag inline-flex items-center px-4 py-2 m-2 rounded-full text-sm font-medium 
        bg-indigo-600 text-white transition-all duration-300 cursor-pointer
        ${isHovered ? 'transform scale-110 bg-indigo-500 shadow-lg shadow-indigo-500/50' : 'hover:bg-indigo-700'}
        active:scale-95`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onTouchStart={() => setIsHovered(true)}
      onTouchEnd={() => setIsHovered(false)}
    >
      <Hash className={`w-4 h-4 mr-1 transition-transform duration-300 ${isHovered ? 'rotate-12' : ''}`} />
      {text}
    </div>
  );
};

function App() {
  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center overflow-hidden">
      <div className="w-[60%] relative">
        <div className="tag-list">
          {[...new Array(ROWS)].map((_, i) => (
            <InfiniteLoopSlider
              key={i}
              duration={random(DURATION - 5000, DURATION + 5000)}
              reverse={i % 2 === 0}
            >
              {shuffle(TAGS).slice(0, TAGS_PER_ROW).map(tag => (
                <Tag text={tag} key={tag} />
              ))}
            </InfiniteLoopSlider>
          ))}
        </div>
        <div className="fade-left" />
        <div className="fade-right" />
      </div>
    </div>
  );
}

export default App;